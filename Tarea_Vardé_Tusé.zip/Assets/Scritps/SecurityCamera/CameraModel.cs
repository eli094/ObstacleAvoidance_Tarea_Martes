using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraModel : MonoBehaviour
{
    private bool isDetecting;

    public bool IsDetecting { get { return isDetecting; } set { isDetecting = value; } }

    
}
